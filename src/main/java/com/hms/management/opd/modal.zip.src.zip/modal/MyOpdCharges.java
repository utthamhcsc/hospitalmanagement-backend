/*    */ package modal;@Entity
/*    */ @Table(name = "myopdcharges")
/*    */ public class MyOpdCharges { @Id
/*    */   @GeneratedValue(strategy = GenerationType.AUTO)
/*    */   private int id;
/*    */   private String opdId;
/*    */   private String chargeType;
/*    */   private String chargeCategory;
/*    */   private String description;
/*    */   
/*    */   public MyOpdCharges(int id, String opdId, String chargeType, String chargeCategory, String description, String code, float standardCharge, String date, String status, float tpaCharge, float appliedCharge) {
/* 12 */     this.id = id; this.opdId = opdId; this.chargeType = chargeType; this.chargeCategory = chargeCategory; this.description = description; this.code = code; this.standardCharge = standardCharge; this.date = date; this.status = status; this.tpaCharge = tpaCharge; this.appliedCharge = appliedCharge;
/*    */   } private String code; private float standardCharge; private String date; private String status; private float tpaCharge; private float appliedCharge; public MyOpdCharges() {}
/*    */   public void setId(int id) {
/* 15 */     this.id = id; } public void setOpdId(String opdId) { this.opdId = opdId; } public void setChargeType(String chargeType) { this.chargeType = chargeType; } public void setChargeCategory(String chargeCategory) { this.chargeCategory = chargeCategory; } public void setDescription(String description) { this.description = description; } public void setCode(String code) { this.code = code; } public void setStandardCharge(float standardCharge) { this.standardCharge = standardCharge; } public void setDate(String date) { this.date = date; } public void setStatus(String status) { this.status = status; } public void setTpaCharge(float tpaCharge) { this.tpaCharge = tpaCharge; } public void setAppliedCharge(float appliedCharge) { this.appliedCharge = appliedCharge; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof com.hms.management.opd.modal.MyOpdCharges)) return false;  com.hms.management.opd.modal.MyOpdCharges other = (com.hms.management.opd.modal.MyOpdCharges)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  Object this$opdId = getOpdId(), other$opdId = other.getOpdId(); if ((this$opdId == null) ? (other$opdId != null) : !this$opdId.equals(other$opdId)) return false;  Object this$chargeType = getChargeType(), other$chargeType = other.getChargeType(); if ((this$chargeType == null) ? (other$chargeType != null) : !this$chargeType.equals(other$chargeType)) return false;  Object this$chargeCategory = getChargeCategory(), other$chargeCategory = other.getChargeCategory(); if ((this$chargeCategory == null) ? (other$chargeCategory != null) : !this$chargeCategory.equals(other$chargeCategory)) return false;  Object this$description = getDescription(), other$description = other.getDescription(); if ((this$description == null) ? (other$description != null) : !this$description.equals(other$description)) return false;  Object this$code = getCode(), other$code = other.getCode(); if ((this$code == null) ? (other$code != null) : !this$code.equals(other$code)) return false;  if (Float.compare(getStandardCharge(), other.getStandardCharge()) != 0) return false;  Object this$date = getDate(), other$date = other.getDate(); if ((this$date == null) ? (other$date != null) : !this$date.equals(other$date)) return false;  Object this$status = getStatus(), other$status = other.getStatus(); return ((this$status == null) ? (other$status != null) : !this$status.equals(other$status)) ? false : ((Float.compare(getTpaCharge(), other.getTpaCharge()) != 0) ? false : (!(Float.compare(getAppliedCharge(), other.getAppliedCharge()) != 0))); } protected boolean canEqual(Object other) { return other instanceof com.hms.management.opd.modal.MyOpdCharges; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); Object $opdId = getOpdId(); result = result * 59 + (($opdId == null) ? 43 : $opdId.hashCode()); Object $chargeType = getChargeType(); result = result * 59 + (($chargeType == null) ? 43 : $chargeType.hashCode()); Object $chargeCategory = getChargeCategory(); result = result * 59 + (($chargeCategory == null) ? 43 : $chargeCategory.hashCode()); Object $description = getDescription(); result = result * 59 + (($description == null) ? 43 : $description.hashCode()); Object $code = getCode(); result = result * 59 + (($code == null) ? 43 : $code.hashCode()); result = result * 59 + Float.floatToIntBits(getStandardCharge()); Object $date = getDate(); result = result * 59 + (($date == null) ? 43 : $date.hashCode()); Object $status = getStatus(); result = result * 59 + (($status == null) ? 43 : $status.hashCode()); result = result * 59 + Float.floatToIntBits(getTpaCharge()); return result * 59 + Float.floatToIntBits(getAppliedCharge()); } public String toString() { return "MyOpdCharges(id=" + getId() + ", opdId=" + getOpdId() + ", chargeType=" + getChargeType() + ", chargeCategory=" + getChargeCategory() + ", description=" + getDescription() + ", code=" + getCode() + ", standardCharge=" + getStandardCharge() + ", date=" + getDate() + ", status=" + getStatus() + ", tpaCharge=" + getTpaCharge() + ", appliedCharge=" + getAppliedCharge() + ")"; }
/*    */ 
/*    */   
/*    */   public int getId()
/*    */   {
/* 20 */     return this.id;
/* 21 */   } public String getOpdId() { return this.opdId; }
/* 22 */   public String getChargeType() { return this.chargeType; }
/* 23 */   public String getChargeCategory() { return this.chargeCategory; }
/* 24 */   public String getDescription() { return this.description; }
/* 25 */   public String getCode() { return this.code; }
/* 26 */   public float getStandardCharge() { return this.standardCharge; }
/* 27 */   public String getDate() { return this.date; }
/* 28 */   public String getStatus() { return this.status; }
/* 29 */   public float getTpaCharge() { return this.tpaCharge; } public float getAppliedCharge() {
/* 30 */     return this.appliedCharge;
/*    */   } }


/* Location:              C:\Users\Nagu\Downloads\WEB-INF\classes\!\com\hms\management\opd\modal.zip!\modal\MyOpdCharges.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */