/*    */ package modal;
/*    */ 
/*    */ import javax.persistence.Entity;
/*    */ import javax.persistence.Id;
/*    */ 
/*    */ @Entity
/*    */ @Table(name = "myopddiagnosis")
/*    */ public class MyOpdDiagnosis {
/*    */   @Id
/*    */   private String opdId;
/*    */   private String reportType;
/*    */   
/* 13 */   public MyOpdDiagnosis(String opdId, String reportType, String document, String description, String reportDate) { this.opdId = opdId; this.reportType = reportType; this.document = document; this.description = description; this.reportDate = reportDate; } private String document; private String description; private String reportDate; public void setOpdId(String opdId) {
/* 14 */     this.opdId = opdId; } public void setReportType(String reportType) { this.reportType = reportType; } public void setDocument(String document) { this.document = document; } public void setDescription(String description) { this.description = description; } public void setReportDate(String reportDate) { this.reportDate = reportDate; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof com.hms.management.opd.modal.MyOpdDiagnosis)) return false;  com.hms.management.opd.modal.MyOpdDiagnosis other = (com.hms.management.opd.modal.MyOpdDiagnosis)o; if (!other.canEqual(this)) return false;  Object this$opdId = getOpdId(), other$opdId = other.getOpdId(); if ((this$opdId == null) ? (other$opdId != null) : !this$opdId.equals(other$opdId)) return false;  Object this$reportType = getReportType(), other$reportType = other.getReportType(); if ((this$reportType == null) ? (other$reportType != null) : !this$reportType.equals(other$reportType)) return false;  Object this$document = getDocument(), other$document = other.getDocument(); if ((this$document == null) ? (other$document != null) : !this$document.equals(other$document)) return false;  Object this$description = getDescription(), other$description = other.getDescription(); if ((this$description == null) ? (other$description != null) : !this$description.equals(other$description)) return false;  Object this$reportDate = getReportDate(), other$reportDate = other.getReportDate(); return !((this$reportDate == null) ? (other$reportDate != null) : !this$reportDate.equals(other$reportDate)); } protected boolean canEqual(Object other) { return other instanceof com.hms.management.opd.modal.MyOpdDiagnosis; } public int hashCode() { int PRIME = 59; result = 1; Object $opdId = getOpdId(); result = result * 59 + (($opdId == null) ? 43 : $opdId.hashCode()); Object $reportType = getReportType(); result = result * 59 + (($reportType == null) ? 43 : $reportType.hashCode()); Object $document = getDocument(); result = result * 59 + (($document == null) ? 43 : $document.hashCode()); Object $description = getDescription(); result = result * 59 + (($description == null) ? 43 : $description.hashCode()); Object $reportDate = getReportDate(); return result * 59 + (($reportDate == null) ? 43 : $reportDate.hashCode()); } public String toString() { return "MyOpdDiagnosis(opdId=" + getOpdId() + ", reportType=" + getReportType() + ", document=" + getDocument() + ", description=" + getDescription() + ", reportDate=" + getReportDate() + ")"; }
/*    */   
/*    */   public MyOpdDiagnosis() {}
/*    */   
/* 18 */   public String getOpdId() { return this.opdId; }
/* 19 */   public String getReportType() { return this.reportType; }
/* 20 */   public String getDocument() { return this.document; }
/* 21 */   public String getDescription() { return this.description; } public String getReportDate() {
/* 22 */     return this.reportDate;
/*    */   }
/*    */ }


/* Location:              C:\Users\Nagu\Downloads\WEB-INF\classes\!\com\hms\management\opd\modal.zip!\modal\MyOpdDiagnosis.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */