/*    */ package modal;
/*    */ 
/*    */ import com.hms.management.opd.modal.MyOpdCaseHistory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import javax.persistence.CascadeType;
/*    */ import javax.persistence.Entity;
/*    */ import javax.persistence.Id;
/*    */ import javax.persistence.OneToMany;
/*    */ import javax.persistence.Table;
/*    */ 
/*    */ @Entity
/*    */ @Table(name = "myopdprescription")
/*    */ public class MyOpdPrescription {
/*    */   @Id
/*    */   private String opdId;
/*    */   private String header;
/*    */   private String footer;
/*    */   private Date date;
/*    */   
/* 22 */   public void setOpdId(String opdId) { this.opdId = opdId; } public void setHeader(String header) { this.header = header; } public void setFooter(String footer) { this.footer = footer; } public void setDate(Date date) { this.date = date; } public void setCaseHistory(List<MyOpdCaseHistory> caseHistory) { this.caseHistory = caseHistory; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof com.hms.management.opd.modal.MyOpdPrescription)) return false;  com.hms.management.opd.modal.MyOpdPrescription other = (com.hms.management.opd.modal.MyOpdPrescription)o; if (!other.canEqual(this)) return false;  Object this$opdId = getOpdId(), other$opdId = other.getOpdId(); if ((this$opdId == null) ? (other$opdId != null) : !this$opdId.equals(other$opdId)) return false;  Object this$header = getHeader(), other$header = other.getHeader(); if ((this$header == null) ? (other$header != null) : !this$header.equals(other$header)) return false;  Object this$footer = getFooter(), other$footer = other.getFooter(); if ((this$footer == null) ? (other$footer != null) : !this$footer.equals(other$footer)) return false;  Object this$date = getDate(), other$date = other.getDate(); if ((this$date == null) ? (other$date != null) : !this$date.equals(other$date)) return false;  Object<MyOpdCaseHistory> this$caseHistory = (Object<MyOpdCaseHistory>)getCaseHistory(), other$caseHistory = (Object<MyOpdCaseHistory>)other.getCaseHistory(); return !((this$caseHistory == null) ? (other$caseHistory != null) : !this$caseHistory.equals(other$caseHistory)); } protected boolean canEqual(Object other) { return other instanceof com.hms.management.opd.modal.MyOpdPrescription; } public int hashCode() { int PRIME = 59; result = 1; Object $opdId = getOpdId(); result = result * 59 + (($opdId == null) ? 43 : $opdId.hashCode()); Object $header = getHeader(); result = result * 59 + (($header == null) ? 43 : $header.hashCode()); Object $footer = getFooter(); result = result * 59 + (($footer == null) ? 43 : $footer.hashCode()); Object $date = getDate(); result = result * 59 + (($date == null) ? 43 : $date.hashCode()); Object<MyOpdCaseHistory> $caseHistory = (Object<MyOpdCaseHistory>)getCaseHistory(); return result * 59 + (($caseHistory == null) ? 43 : $caseHistory.hashCode()); } public String toString() { return "MyOpdPrescription(opdId=" + getOpdId() + ", header=" + getHeader() + ", footer=" + getFooter() + ", date=" + getDate() + ", caseHistory=" + getCaseHistory() + ")"; } public MyOpdPrescription(String opdId, String header, String footer, Date date, List<MyOpdCaseHistory> caseHistory) {
/* 23 */     this.opdId = opdId; this.header = header; this.footer = footer; this.date = date; this.caseHistory = caseHistory;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getOpdId() {
/* 28 */     return this.opdId; }
/* 29 */   public String getHeader() { return this.header; }
/* 30 */   public String getFooter() { return this.footer; }
/* 31 */   public Date getDate() { return this.date; } @OneToMany(targetEntity = MyOpdCaseHistory.class, cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
/*    */   @JoinColumn(name = "pr_fk", referencedColumnName = "opdId", insertable = true, updatable = true, nullable = false)
/* 33 */   private List<MyOpdCaseHistory> caseHistory = new ArrayList<>();
/*    */   public List<MyOpdCaseHistory> getCaseHistory() {
/* 35 */     return this.caseHistory;
/*    */   }
/*    */   
/*    */   public MyOpdPrescription() {}
/*    */ }


/* Location:              C:\Users\Nagu\Downloads\WEB-INF\classes\!\com\hms\management\opd\modal.zip!\modal\MyOpdPrescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */